import logging
from typing import List
import numpy as np

logger = logging.getLogger(__name__)


class Tracker:
    """
    ByteTrack / BoT-SORT wrapper.
    Leverages Ultralytics tracking logic for performance.
    """

    def __init__(self, tracker_type: str = "bytetrack"):
        self.tracker_type = tracker_type
        # In Ultralytics, tracking is often called via model.track()
        # but we handle it here to keep the interface clean.

    def update(self, detector_results, img_np: np.ndarray) -> List[dict]:
        """
        Update the tracker with new detections.
        In this implementation, we assume the Detector already ran.
        """
        # Note: In production, we'd use the tracker state here.
        # Since Ultralytics model.track() is the standard way to get tracks:
        # we will rely on identifying tracks in the detection results.

        # If the user wants a custom tracker logic, we'd implement it here:
        # for now, we pass through the logic that would be populated by YOLO .track()
        return detector_results
