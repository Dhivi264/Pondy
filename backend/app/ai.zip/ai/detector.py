import threading
import logging
from typing import List
import numpy as np

logger = logging.getLogger(__name__)


class Detector:
    """
    YOLO11 Person Detector.
    Supports ONNX and PyTorch backends.
    """

    def __init__(self, model_path: str, device: str = "cpu", tracker_type: str = "bytetrack"):
        self.model_path = model_path
        self.device = device
        self.tracker_type = tracker_type
        self.lock = threading.Lock()
        self.model = None
        self._load_model()

    def _load_model(self):
        """Initialize the YOLO11 model with TensorRT optimization."""
        try:
            from ultralytics import YOLO
            import os

            # 1. Load base PyTorch model
            self.model = YOLO(self.model_path)
            
            # 2. Optimized Export to TensorRT (NVIDIA's best performance format)
            if self.device == "cuda":
                # Check if a .engine file already exists for this model
                engine_path = self.model_path.replace('.pt', '.engine')
                if not os.path.exists(engine_path):
                    logger.info(f"[Detector] First-run: Exporting {self.model_path} to TensorRT (.engine) for RTX 3050...")
                    # Export with half-precision (FP16) for 2x speedup on RTX series
                    self.model.export(format='engine', half=True, dynamic=True, simplify=True)
                
                # Load the optimized engine if it exists
                if os.path.exists(engine_path):
                    self.model = YOLO(engine_path)
                    logger.info(f"[Detector] Using optimized TensorRT engine: {engine_path}")
                else:
                    self.model.to(self.device)
            else:
                self.model.to(self.device)

            logger.info(
                f"[Detector] AI Pipeline initialized on {self.device} (FP16 enabled)"
            )
        except Exception as e:
            logger.error(f"[Detector] Failed to optimize model: {e}")

    def detect(
        self, img_np: np.ndarray, conf: float = 0.5, classes: List[int] = [0]
    ) -> List[dict]:
        """
        Run inference on a frame.
        Default class [0] is 'person'.
        """
        if self.model is None:
            return []

        try:
            with self.lock:
                # Use model.track instead of predict to enable ByteTrack/BoT-SORT
                tracker_arg = f"{self.tracker_type}.yaml"
                results = self.model.track(
                    img_np, conf=conf, classes=classes, persist=True, verbose=False, tracker=tracker_arg
                )

            detections = []
            for r in results:
                boxes = r.boxes
                for box in boxes:
                    x1, y1, x2, y2 = box.xyxy[0].tolist()
                    # track_id is available when using model.track()
                    t_id = int(box.id[0]) if box.id is not None else 0
                    detections.append(
                        {
                            "box": [x1, y1, x2, y2],
                            "confidence": float(box.conf[0]),
                            "class_id": int(box.cls[0]),
                            "track_id": t_id,
                        }
                    )
            return detections
        except Exception as e:
            logger.error(f"[Detector] Inference error: {e}")
            return []
