import av
import threading
import queue
import time
import logging
from typing import Dict, Optional, Tuple
from datetime import datetime

logger = logging.getLogger(__name__)


class StreamManager:
    """
    Manages multiple RTSP camera streams using PyAV for high-performance decoding.
    Handles frame buffering, skipping, and health monitoring.
    """

    def __init__(self):
        self.active_streams: Dict[str, threading.Thread] = {}
        self._latest_frame: Dict[str, Optional[Tuple[datetime, object]]] = {}
        # --- Dual Pipeline Separation (STRICT) ---
        self._ai_queues: Dict[str, queue.Queue] = {}
        # -----------------------------------------
        self._running: Dict[str, bool] = {}
        self._health: Dict[str, str] = {}
        self._last_frame_time: Dict[str, float] = {}
        self._frame_counts: Dict[str, int] = {}

    def add_camera(self, camera_id: str, url: str, queue_size: int = 5):
        """Start a background thread to ingest a camera stream."""
        if camera_id in self.active_streams:
            self.stop_camera(camera_id)

        self._latest_frame[camera_id] = None
        self._ai_queues[camera_id] = queue.Queue(maxsize=1)  # AI Pipeline
        self._running[camera_id] = True
        self._health[camera_id] = "connecting"
        self._frame_counts[camera_id] = 0

        thread = threading.Thread(
            target=self._ingest_loop,
            args=(camera_id, url),
            name=f"Stream-{camera_id}",
            daemon=True,
        )
        thread.start()
        self.active_streams[camera_id] = thread
        logger.info(f"[Stream] Added camera {camera_id}: {url}")

    def stop_camera(self, camera_id: str):
        """Stop a specific camera stream."""
        self._running[camera_id] = False
        if camera_id in self.active_streams:
            self.active_streams[camera_id].join(timeout=2.0)
            del self.active_streams[camera_id]
        if camera_id in self._latest_frame:
            del self._latest_frame[camera_id]
        logger.info(f"[Stream] Stopped camera {camera_id}")

    def get_frame(
        self, camera_id: str, timeout: float = 1.0
    ) -> Optional[Tuple[datetime, object]]:
        """Retrieve the latest frame for LIVE VIEW (fast route)."""
        return self._latest_frame.get(camera_id)

    def get_ai_frame(
        self, camera_id: str, timeout: float = 0.5
    ) -> Optional[Tuple[datetime, object]]:
        """Consume a frame for AI processing (background route)."""
        if camera_id not in self._ai_queues:
            return None
        try:
            return self._ai_queues[camera_id].get(timeout=timeout)
        except queue.Empty:
            return None

    def get_health(self, camera_id: str) -> str:
        """Return the health status of a camera."""
        return self._health.get(camera_id, "unknown")

    def _ingest_loop(self, camera_id: str, url: str):
        """Internal loop for frame ingestion."""
        # Disable webcam (local camera) handling as per request
        if url.isdigit():
            self._health[camera_id] = "error: webcam disabled"
            logger.warning(f"[Stream] Webcam {url} is disabled. Retrying in 30s...")
            time.sleep(30)  # Long backoff — don't spam
            return

        consecutive_fails = 0
        MAX_FAILS = 5  # Stop spamming after 5 consecutive grab failures

        while self._running[camera_id]:
            # RTSP/Remote stream via PyAV
            container = None
            try:
                # Force TCP transport for stable multi-camera connections
                container = av.open(
                    url, 
                    timeout=5.0, 
                    options={'rtsp_transport': 'tcp', 'stimeout': '5000000'}
                )
                stream = container.streams.video[0]
                stream.thread_type = "AUTO"

                self._health[camera_id] = "online"
                logger.info(f"[Stream] Connected to remote {camera_id} via TCP")

                for frame in container.decode(video=0):
                    if not self._running[camera_id]:
                        break

                    img = frame.to_image()
                    self._push_frame(camera_id, img)
                    self._last_frame_time[camera_id] = time.time()

            except Exception as e:
                self._health[camera_id] = f"error: {str(e)}"
                logger.error(f"[Stream] {camera_id} remote error: {e}")
                time.sleep(5)
            finally:
                if container:
                    container.close()

    def _push_frame(self, camera_id: str, img):
        """Helper to push frame to dual buffers (Stream + AI)."""
        # 1. STREAM PIPELINE: Fast update for MJPEG proxy
        now = datetime.now()
        self._latest_frame[camera_id] = (now, img)

        # 2. AI PIPELINE: Non-blocking push for background processing
        if camera_id in self._ai_queues:
            q = self._ai_queues[camera_id]
            try:
                # If AI is slow and queue is full, drop the old frame
                if q.full():
                    q.get_nowait()
                q.put_nowait((now, img))
            except queue.Full:
                pass
            except queue.Empty:
                pass


stream_manager = StreamManager()
